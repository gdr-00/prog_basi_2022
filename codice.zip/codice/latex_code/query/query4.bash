+-----------+----------+------------------+
| nome      | cognome  | cf               |
+-----------+----------+------------------+
| Priscilla | Cattaneo | FODMA09D54A347EX |
| Ludovica  | Argurio  | BRGGLI78B51M130S |
| Nicola    | Zampa    | PRTRSN78H13L359O |
| Delfino   | Zamorani | RFFGTN98C65M260G |
| Carolina  | Broggini | LPPGLR37D07B883S |
+-----------+----------+------------------+