+--------------+-----------+------------------+---------------+----------------------+
| nome         | cognome   | cf               | puo_recensire | biglietti_acquistati |
+--------------+-----------+------------------+---------------+----------------------+
| Lisa         | Babbo     | ZMNPTZ82H21B629G | si            | 10                   |
| Michelangelo | Brugnaro  | RGRLRT56L24M298J | si            | 10                   |
| Nicola       | Zampa     | PRTRSN78H13L359O | no            | 10                   |
| Priscilla    | Cattaneo  | FODMA09D54A347EX | si            | 11                   |
| Federico     | Zabarella | CGNVLT50T15G211Y | si            | 17                   |
| Martina      | Boezio    | BRCGNE08M11M180X | si            | 9                    |
| Carolina     | Broggini  | LPPGLR37D07B883S | no            | 13                   |
| Delfino      | Zamorani  | RFFGTN98C65M260G | no            | 8                    |
| Ornella      | Sforza    | SLVGBL37D47H270I | si            | 13                   |
| Ludovica     | Argurio   | BRGGLI78B51M130S | no            | 8                    |
+--------------+-----------+------------------+---------------+----------------------+