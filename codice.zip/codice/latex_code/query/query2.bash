+---------+--------+----------------+
| nome    | citta  | incassi_totali |
+---------+--------+----------------+
| Cinema8 | Citta8 | $101.00        |
| Cinema9 | Citta9 | $107.00        |
| Cinema1 | Citta1 | $114.00        |
| Cinema6 | Citta6 | $138.00        |
| Cinema4 | Citta4 | $157.00        |
| Cinema7 | Citta7 | $165.00        |
+---------+--------+----------------+