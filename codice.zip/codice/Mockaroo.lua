Cinema1, Cinema2, Cinema3, Cinema4, Cinema5, Cinema6, Cinema7, Cinema8, Cinema9, Cinema10
Avengers Assemble, Novgorodtsy, Avengers: Endgame, Avengers: Infinity War, Avengers: Age of Ultron, Avengers of Justice: Farce Wars, Crippled Avengers, The Avengers, Doctor Strange in the Multiverse of Madness, The Northman, Morbius, Old, Doctor Strange
if field("nome_film") == 'Avengers Assemble' then '2012-03-01'
elsif field("nome_film") == 'Novgorodtsy' then '1943-04-11'
elsif field("nome_film") == 'Avengers: Endgame' then '2019-06-06'
elsif field("nome_film") == 'Avengers: Infinity War' then '2018-04-12'
elsif field("nome_film") == 'Avengers: Age of Ultron' then '2015-01-01'
elsif field("nome_film") == 'Avengers of Justice: Farce Wars' then '2018-02-01'
elsif field("nome_film") == 'Crippled Avengers' then '1978-06-07'
elsif field("nome_film") == 'The Avengers' then '1998-07-17'
elsif field("nome_film") == 'Doctor Strange in the Multiverse of Madness' then '2022-03-03'
elsif field("nome_film") == 'The Northman' then '2022-05-27'
elsif field("nome_film") == 'Morbius' then '2022-01-11'
elsif field("nome_film") == 'Old' then '2021-04-30'
elsif field("nome_film") == 'Doctor Strange' then '2016-09-22'
else '' end
if field("nome_cinema") == 'Cinema1' then 'Citta1'
elsif field("nome_cinema") == 'Cinema2' then 'Citta2'
elsif field("nome_cinema") == 'Cinema3' then 'Citta3'
elsif field("nome_cinema") == 'Cinema4' then 'Citta4'
elsif field("nome_cinema") == 'Cinema5' then 'Citta5'
elsif field("nome_cinema") == 'Cinema6' then 'Citta6'
elsif field("nome_cinema") == 'Cinema7' then 'Citta7'
elsif field("nome_cinema") == 'Cinema8' then 'Citta8'
elsif field("nome_cinema") == 'Cinema9' then 'Citta9'
elsif field("nome_cinema") == 'Cinema10' then 'Citta10'
else '' end
this = date(field("anno_uscita"), '%Y-%m-%d')+days(random(1,10))
gian06@hotmail.it, paulina13@gmail.com, lucreziacorradi@live.com, dligorio@hotmail.it, boccionipietro@tiscali.it, ipiccinni@outlook.com, paoloantonioni@yahoo.com, piergiorgio37@gmail.com, mazzacuratimarcantonio@tele2.it, qnonis@vodafone.it
Cinema1, Cinema2, Cinema3, Cinema4, Cinema5, Cinema6, Cinema7, Cinema8, Cinema9, Cinema10